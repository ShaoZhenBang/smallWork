package Interface;

import java.sql.SQLException;

public interface CheckLoginInterface {
    boolean checkLogin(String id, String password)throws SQLException;
}
