package Interface;

import java.sql.SQLException;

public interface UpdateStateInterface{
    void updateState(String id)throws SQLException;
}
