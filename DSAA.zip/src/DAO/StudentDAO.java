package DAO;

import java.sql.*;

import Interface.CheckLoginInterface;
import Interface.UpdateStateInterface;
import Model.Student;

public class StudentDAO implements UpdateStateInterface, CheckLoginInterface {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/DSAA?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "SZB";
    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public Student getStudentInformationById(String id)throws SQLException{
        Connection conn = getConn();
        Statement stmt;
        ResultSet rs;
        assert conn != null;
        stmt = conn.createStatement();
        String sql ="SELECT*FROM student WHERE id='"+id+"'";
        rs = stmt.executeQuery(sql);
        Student s=new Student();
        while(rs.next()){
            s.setFaculty(rs.getString("faculty"));
            s.setMajor(rs.getString("major"));
            s.setId(rs.getString("id"));
            s.setName(rs.getString("name"));
            s.setPhone(rs.getString("phone"));
            s.setDormitory(rs.getString("dormitory"));
            s.setParentName(rs.getString("parentName"));
            s.setParentPhone(rs.getString("parentPhone"));
        }
        rs.close();
        stmt.close();
        conn.close();
        return s;
    }

    public void updateStudentInformation(Student s)throws SQLException{
        Connection connect=getConn();
        Statement stmt;
        assert connect!=null;
        stmt=connect.createStatement();
        String sql = "UPDATE student SET id='"
                + s.getId()
                + "',SET name='"
                + s.getName()
                + "',SET dormitory='"
                + s.getDormitory()
                + "',SET phone'"
                + s.getPhone()
                + "',SET parentName='"
                + s.getParentName()
                + "',SET parentPhone='"
                + s.getParentPhone()
                + "',SET faculty='"
                + s.getFaculty()
                + "',SET major='"
                + s.getMajor()
                + "',SET state='"
                + 0
                + "'"
                + ")";;
        stmt.executeUpdate(sql);
        stmt.close();
        connect.close();
    }

    public void updateState(String id)throws SQLException{
        Connection conn=getConn();
        Statement stmt;
        assert conn!=null;
        stmt=conn.createStatement();
        String sql="UPDATE student SET state=1 WHERE id='"+id+"'";
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }

    public boolean checkLogin(String id,String password)throws SQLException{
        Connection conn=getConn();
        Statement stmt;
        ResultSet rs;
        assert conn!=null;
        stmt=conn.createStatement();
        String sql="SELECT *FROM student WHERE id='"+id+"'";
        rs=stmt.executeQuery(sql);
        while(rs.next()){
            if(password.equals(rs.getString("password"))){
                rs.close();
                stmt.close();
                conn.close();
                return true;
            }
        }
        rs.close();
        stmt.close();
        conn.close();
        return false;
    }

}
