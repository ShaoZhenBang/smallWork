package DAO;

import Interface.CheckLoginInterface;

import java.sql.*;

public class AdministratorDAO implements CheckLoginInterface {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/DSAA?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "SZB";
    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean checkLogin(String id, String password) throws SQLException {
        Connection conn=getConn();
        Statement stmt;
        ResultSet rs;
        assert conn!=null;
        stmt=conn.createStatement();
        String sql="SELECT *FROM administrator WHERE id='"+id+"'";
        rs=stmt.executeQuery(sql);
        while(rs.next()){
            if(password.equals(rs.getString("password"))){
                stmt.close();
                conn.close();
                rs.close();
                return true;
            }
        }
        stmt.close();
        conn.close();
        rs.close();
        return false;
    }
}
