package DAO;
import java.sql.*;
import java.util.*;

import Interface.UpdateStateInterface;
import Model.Record;

public class RecordDAO {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/DSAA?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "SZB";
    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    //faculty用于锁定所查询学院视图名称,由用户在JSP输入参数传递到SERVLET实现。
    public List<Record> getRecordsByColor(String healthCodeColor,String faculty)throws SQLException{
        Connection connect = getConn();
        Statement stmt;
        ResultSet rs;
        assert connect != null;
        stmt = connect.createStatement();
        String sql = "SELECT*FROM '"+faculty+"' WHERE healthCode='"+healthCodeColor+"'";
        rs = stmt.executeQuery(sql);
        List<Record> records = new ArrayList<>();
        while (rs.next()) {
            Record rec=new Record();
            rec.setItinerary(rs.getString("itinerary"));
            rec.setHealthCondition(rs.getString("healthCondition"));
            rec.setRecentlyContactCondition(rs.getString("recentlyContactCondition"));
            rec.setHealthCode(rs.getString("healthCode"));
            rec.setId(rs.getString("id"));
            records.add(rec);
        }
        rs.close();
        stmt.close();
        connect.close();
        return records;
    }
    public void addRecord(Record r)throws SQLException{
        Connection connect=getConn();
        Statement stmt;
        assert connect!=null;
        stmt=connect.createStatement();
        if(r.getRecentlyContactCondition().equals("yes")){
            r.setHealthCode("yellow");
        }
        String sql = "INSERT INTO record (healthCode,recentlyContactCondition,healthCondition,itinerary,id) VALUES ('"
                +r.getHealthCode()
                + "','"
                +r.getRecentlyContactCondition()
                + "','"
                +r.getHealthCondition()
                + "','"
                +r.getItinerary()
                + "','"
                +r.getId()
                + "'"
                + ")";
        stmt.executeUpdate(sql);
        UpdateStateInterface usi=new StudentDAO();
        usi.updateState(r.getId());
        stmt.close();
        connect.close();
    }

    public List<Record> getStudentState0(String faculty) throws SQLException {
        Connection connect = getConn();
        Statement stmt;
        ResultSet rs = null;
        assert connect != null;
        stmt = connect.createStatement();
        String sql = "SELECT id,name,major FROM student WHERE faculty='"+faculty+"' AND state=0";
        try {
            rs = stmt.executeQuery(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        List<Record> records = new ArrayList<>();
        while (true){
            assert rs != null;
            if (!rs.next()) break;
            Record rec=new Record();
            rec.setItinerary(rs.getString("itinerary"));
            rec.setHealthCondition(rs.getString("healthCondition"));
            rec.setRecentlyContactCondition(rs.getString("recentlyContactCondition"));
            rec.setHealthCode(rs.getString("healthCode"));
            rec.setId(rs.getString("id"));
            records.add(rec);
        }
        rs.close();
        stmt.close();
        connect.close();
        return records;
    }
}
