package Servlet;

import DAO.AdministratorDAO;
import DAO.StudentDAO;
import Service.CheckLoginComplement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String ID=request.getParameter("sID");
        String Password=request.getParameter("sPassword");
        CheckLoginComplement clc=new CheckLoginComplement();
        response.setHeader("Content-Type","text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out= response.getWriter();
        HttpSession session;
        try {
            if(clc.getCli(new StudentDAO()).checkLogin(ID,Password)){
                session=request.getSession();
                session.setAttribute("identity","student");
                session.setAttribute("id",ID);
                out.println("<script>alert('学生登录成功!');"+"location.href='initialPageForStudent.jsp';</script>");
            }else if(clc.getCli(new AdministratorDAO()).checkLogin(ID,Password)){
                session=request.getSession();
                session.setAttribute("identity","administrator");
                session.setAttribute("id",ID);
                out.println("<script>alert('管理员登录成功!');"+"location.href='initialPageForAdministrator.jsp';</script>");
            }else{
                out.println("<script>alert('用户名或密码错误!');"+"location.href='Login.jsp';</script>");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    @Override
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
        doGet(request,response);
    }

}