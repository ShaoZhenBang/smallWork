package Servlet;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class LoginFilterStudent implements Filter {


    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain filterC) throws IOException, ServletException {
        HttpServletRequest hsRequest = (HttpServletRequest) request;
        String identity= (String) hsRequest.getSession().getAttribute("identity");
        if (identity==null) {
            hsRequest.getRequestDispatcher("../Index.jsp").forward(request, response);
        } else {
            filterC.doFilter(request,response);
        }
    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub

    }

    @Override
    public void init(FilterConfig arg0) {
        // TODO Auto-generated method stub

    }
}