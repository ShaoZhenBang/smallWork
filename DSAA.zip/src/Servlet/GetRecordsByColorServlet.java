package Servlet;

import DAO.RecordDAO;
import Model.Record;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetRecordsByColorServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String color=request.getParameter("color");
        String faculty=request.getParameter("faculty");
        RecordDAO recordDAO=new RecordDAO();
        List<Record> records=new ArrayList<>();
        try {
            records=recordDAO.getRecordsByColor(color,faculty);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("records",records);
        request.getRequestDispatcher("web/JSPAdministrator/showStudentByHealthCode.jsp").forward(request, response);

    }
}
