package Model;

public class Record {
    private String itinerary;
    private String healthCode;
    private String healthCondition;
    private String recentlyContactCondition;
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRecentlyContactCondition() {
        return recentlyContactCondition;
    }

    public void setRecentlyContactCondition(String recentlyContactCondition) {
        this.recentlyContactCondition = recentlyContactCondition;
    }

    public String getHealthCondition() {
        return healthCondition;
    }

    public void setHealthCondition(String healthCondition) {
        this.healthCondition = healthCondition;
    }

    public String getHealthCode() {
        return healthCode;
    }

    public void setHealthCode(String healthCode) {
        this.healthCode = healthCode;
    }

    public String getItinerary() {
        return itinerary;
    }

    public void setItinerary(String itinerary) {
        this.itinerary = itinerary;
    }

}
