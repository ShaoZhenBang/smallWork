package Service;

import Interface.CheckLoginInterface;

public class CheckLoginComplement{
    private CheckLoginInterface cli;

    public CheckLoginInterface getCli(CheckLoginInterface cli){
        this.cli=cli;
        return this.cli;
    }
}
