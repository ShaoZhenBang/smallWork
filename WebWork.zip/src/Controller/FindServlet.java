package Controller;

import DAO.ProductDAO;
import Model.Product;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class FindServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name= request.getParameter("name");
        ProductDAO p=new ProductDAO();
        List<Product> products=null;
        try {
            products=p.getProductByName(name);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("products",products);
        request.getRequestDispatcher("/productID.jsp").forward(request, response);
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}