package Controller;
import Model.Product;
import DAO.ProductDAO;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class ListServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException {
        ProductDAO pm=new ProductDAO();
        HttpSession session=request.getSession();
        int page=Integer.parseInt(String.valueOf(session.getAttribute("page")))-1;
        List<Product> products = null;
        try {
            int s=pm.getAllProduct().size();
            if(s>=2*(page+1)){
            products = pm.getAllProduct().subList(2*page,2*page+2);
            }else{products=pm.getAllProduct().subList(2*page,2*page+2*(page+1)-s);}
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("products",products);
        request.getRequestDispatcher("/productList.jsp").forward(request, response);
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
