package Controller;

import DAO.UserDAO;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String userName=request.getParameter("userName");
        String password=request.getParameter("password");
        UserDAO u=new UserDAO();
        response.setHeader("content-type","text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out= response.getWriter();
        HttpSession session;
        try {
            int result=u.checkUser(userName,password);
            if(result==2){
                session=request.getSession();
                session.setAttribute("identity","user");
                session.setAttribute("userName",userName);
                session.setAttribute("page",1);
                out.println("<script>alert('用户登录成功!');"+"location.href='initialPage.jsp';</script>");
            }else if(result==0){
                out.println("<script>alert('用户名或密码错误!');"+"location.href='Login.jsp';</script>");
            }else{
                session=request.getSession();
                session.setAttribute("identity","admin");
                session.setAttribute("page",1);
                out.println("<script>alert('管理员登录成功!');"+"location.href='initialPage.jsp';</script>");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
        doGet(request,response);
    }

}
