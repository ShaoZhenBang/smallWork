package Controller;

import DAO.ProductDAO;
import Model.Product;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class updateInventoryServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();
        if((session.getAttribute("identity").equals("user"))){
            PrintWriter out = response.getWriter();
            out.println("<script>alert('no jurisdiction!');location.href='initialPage.jsp';</script>");
        }else{
        int inventory=Integer.parseInt(request.getParameter("inventory"));
        int id=Integer.parseInt(request.getParameter("id"));
        ProductDAO p=new ProductDAO();
        Product pro= null;
        try {
            pro = p.getProductById(id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            p.updateInventory(id,inventory);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("product",pro);
        request.getRequestDispatcher("/view.do").forward(request, response);
    }}
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

}
