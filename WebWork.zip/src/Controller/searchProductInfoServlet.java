package Controller;

import DAO.ProductDAO;
import Model.Product;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class searchProductInfoServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        ProductDAO pm=new ProductDAO();
        Product p=null;
        try {
            p = pm.getProductById(id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        response.setHeader("content-type", "text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        if(p!=null){
            response.getWriter().println(p.getName()+";"+p.getKind()+";"+p.getPrice()+";"+p.getInventory());
        }else{
            response.getWriter().println("null;null;0;0");
        }
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response)throws IOException {
        doGet(request,response);
    }

}
