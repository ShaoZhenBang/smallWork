package Controller;
import Model.Product;
import DAO.ProductDAO;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

public class ViewServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
        String strId = request.getParameter("id");
        int id = Integer.parseInt(strId);
        ProductDAO pm=new ProductDAO();
        Product p= null;
        try {
            p = pm.getProductById(id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("product", p);
        request.getRequestDispatcher("/view.jsp").forward(request, response);
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException {
        doGet(request,response);
    }

}
