package Controller;

import DAO.UserDAO;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class AddUserServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name=request.getParameter("uName");
        String password=request.getParameter("password");
        UserDAO u=new UserDAO();
        try {
            u.addUser(name,password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        response.sendRedirect("showUser.do");
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
        doGet(request,response);
    }
}
