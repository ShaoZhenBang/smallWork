package Controller;

import DAO.ProductDAO;
import Model.Product;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class AddServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
        HttpSession session=request.getSession();
        if((session.getAttribute("identity").equals("user"))){
            PrintWriter out = response.getWriter();
            out.println("<script>alert('no jurisdiction!');location.href='initialPage.jsp';</script>");
        }else{
        String name = request.getParameter("pName");
        String kind = request.getParameter("kind");
        double price = Double.parseDouble(request.getParameter("price"));
        int inventory = Integer.parseInt(request.getParameter("inventory"));
        Product p = new Product();
        p.setInventory(inventory);
        p.setPrice(price);
        p.setKind(kind);
        p.setName(name);
        ProductDAO pm = new ProductDAO();
        try {
            if(pm.addProduct(p)){
                response.sendRedirect("list.do");
            } else{
                PrintWriter out = response.getWriter();
                out.println("<script>alert('Product is existed!');location.href='addProduct.jsp';</script>");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }}
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
        doGet(request,response);
    }

}
