package Controller;

import DAO.ProductDAO;
import Model.Product;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;

public class TakeServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int number=Integer.parseInt(request.getParameter("number"));
        int id=Integer.parseInt(request.getParameter("id"));
        ProductDAO p=new ProductDAO();
        Product pro = null;
        HttpSession session= request.getSession();
        try {
            pro=p.getProductById(id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            p.takeInventory(id,number);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        String date= String.valueOf(new Date(System.currentTimeMillis()));
        try {
            assert pro != null;
            p.record(id,number,pro.getPrice()*number,(String)session.getAttribute("userName"),date);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        PrintWriter out = response.getWriter();
        out.println("<script>alert('take successfully!');location.href='initialPage.jsp';</script>");
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
        doGet(request,response);
    }
}