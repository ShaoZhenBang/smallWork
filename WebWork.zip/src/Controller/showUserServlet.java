package Controller;

import DAO.UserDAO;
import Model.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class showUserServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();
        String identity=(String)session.getAttribute("identity");
        if((identity.equals("user"))){
            response.sendRedirect("initialPage.jsp");
        }else { UserDAO u=new UserDAO();
        List<User> users=new ArrayList<>();
        try {
            users=u.getAllUser();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        request.setAttribute("users",users);
        request.getRequestDispatcher("/commandUser.jsp").forward(request, response);}
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

}