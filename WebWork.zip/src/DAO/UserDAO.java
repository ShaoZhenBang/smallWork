package DAO;

import Model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/test?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "";

    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public int checkUser(String name,String password)throws SQLException{
        if(name.equals("administrator")&&password.equals("Admin1234567890")){
            return 1;
        }
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql="SELECT * FROM user WHERE userName='"+name+"' AND password='"+password+"'";
        ResultSet rs=stmt.executeQuery(sql);
        if(rs.next()){
            rs.close();
            stmt.close();
            conn.close();
            return 2;
        }
        rs.close();
        stmt.close();
        conn.close();
        return 0;
    }
    public void addUser(String name,String password)throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql="INSERT INTO user(userName,password) VALUES ('"+name+"','"+password+"')";
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }
    public void deleteUser(String name)throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql="Delete FROM user WHERE userName='"+name+"'";
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }
    public List<User> getAllUser()throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        List<User> users=new ArrayList<>();
        String sql="SELECT *FROM user";
        ResultSet rs=stmt.executeQuery(sql);
        while (rs.next()){
            User u=new User();
            u.setUserName(rs.getString("userName"));
            u.setPassword(rs.getString("password"));
            users.add(u);
        }
        rs.close();
        stmt.close();
        conn.close();
        return users;
    }
}