package DAO;
import Model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/test?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "";

    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Product> getAllProduct() throws SQLException {
        Connection connect = getConn();
        Statement stmt;
        ResultSet rs;
        assert connect != null;
        stmt = connect.createStatement();
        String sql = "SELECT*FROM product";
        rs = stmt.executeQuery(sql);
        List<Product> products = new ArrayList<>();
        while (rs.next()) {
            Product pro = new Product();
            pro.setId(rs.getInt("id"));
            pro.setName(rs.getString("pName"));
            pro.setInventory(rs.getInt("inventory"));
            pro.setKind(rs.getString("kind"));
            pro.setPrice(rs.getDouble("price"));
            products.add(pro);
        }
        rs.close();
        stmt.close();
        connect.close();
        return products;
    }

    public boolean addProduct(Product p) throws SQLException {
        if(checkProduct(p.getName())) {
            Connection conn = getConn();
            Statement stmt;
            assert conn != null;
            stmt = conn.createStatement();
            String sql = "INSERT INTO product (id,pName,kind,price,inventory) VALUES ('"
                    + p.getId()
                    + "','"
                    + p.getName()
                    + "','"
                    + p.getKind()
                    + "','"
                    + p.getPrice()
                    + "','"
                    + p.getInventory()
                    + "'"
                    + ")";
            stmt.executeUpdate(sql);
            stmt.close();
            conn.close();
        }else{return false;}
        return true;
    }
    public boolean checkProduct(String name)throws SQLException{
        Connection conn = getConn();
        Statement stmt;
        assert conn != null;
        stmt = conn.createStatement();
        String sql="SELECT *FROM product WHERE pName='"+name+"'";
        ResultSet rs=stmt.executeQuery(sql);
        boolean result;
        result= !rs.next();
        stmt.close();
        rs.close();
        return result;
    }

    public Product getProductById(int id) throws SQLException {
        Connection conn = getConn();
        Statement stmt;
        ResultSet rs;
        assert conn != null;
        stmt = conn.createStatement();
        String sql = "SELECT * FROM product WHERE id=" + id;
        rs = stmt.executeQuery(sql);
        Product p=new Product();
        while(rs.next()) {
            p.setId(rs.getInt("id"));
            p.setName(rs.getString("pName"));
            p.setKind(rs.getString("kind"));
            p.setPrice(rs.getDouble("price"));
            p.setInventory(rs.getInt("inventory"));
        }
        rs.close();
        stmt.close();
        conn.close();
        return p;
    }
    public void deleteProduct(int id)throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql = "Delete FROM product WHERE id="+id;
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }

    public List<Product> getProductByKind(String kind) throws SQLException {
        Connection conn = getConn();
        Statement stmt;
        ResultSet rs;
        assert conn != null;
        stmt = conn.createStatement();
        String sql = "SELECT * FROM product WHERE kind='" +kind+"'";
        rs = stmt.executeQuery(sql);
        List<Product> products = new ArrayList<>();
        while(rs.next()) {
            Product p=new Product();
            p.setId(rs.getInt("id"));
            p.setName(rs.getString("pName"));
            p.setKind(rs.getString("kind"));
            p.setPrice(rs.getDouble("price"));
            p.setInventory(rs.getInt("inventory"));
            products.add(p);
        }
        rs.close();
        stmt.close();
        conn.close();
        return products;
    }
    public void updateInventory(int id,int inventory)throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql ="UPDATE product SET inventory="+inventory+" WHERE id="+id;
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }
    public void takeInventory(int id,int inventory)throws SQLException{
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        Product p=getProductById(id);
        int num=p.getInventory()-inventory;
        String sql ="UPDATE product SET inventory="+num+" WHERE id="+id;
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }
    public void record(int id,int inventory,double price,String name,String date) throws SQLException {
        Connection conn = getConn();
        assert conn != null;
        Statement stmt= conn.createStatement();
        String sql="INSERT INTO record(pID,pnumber,price,userName,pdate) VALUES ('"+id+"','"+inventory+"','"+price+"','"+name+"','"+date+"')";
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }
    public List<Product> getProductByName(String name) throws SQLException {
        Connection conn = getConn();
        Statement stmt;
        ResultSet rs;
        assert conn != null;
        stmt = conn.createStatement();
        String sql = "SELECT * FROM product WHERE pName='" +name+"'";
        rs = stmt.executeQuery(sql);
        List<Product> products = new ArrayList<>();
        while(rs.next()) {
            Product p=new Product();
            p.setId(rs.getInt("id"));
            p.setName(rs.getString("pName"));
            p.setKind(rs.getString("kind"));
            p.setPrice(rs.getDouble("price"));
            p.setInventory(rs.getInt("inventory"));
            products.add(p);
        }
        rs.close();
        stmt.close();
        conn.close();
        return products;
    }
}
