package DAO;
import Model.Product;
import Model.Record;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecordDAO {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/test?&useSSL=false&serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "";
    private Connection getConn() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Record> getAllRecord() throws SQLException {
        Connection connect = getConn();
        Statement stmt;
        ResultSet rs;
        assert connect != null;
        stmt = connect.createStatement();
        String sql = "SELECT*FROM record";
        rs = stmt.executeQuery(sql);
        List<Record> records = new ArrayList<>();
        while (rs.next()) {
            Record r=new Record();
            r.setId(rs.getInt("pID"));
            r.setNumber(rs.getInt("pnumber"));
            r.setPrice(rs.getDouble("price"));
            r.setName(rs.getString("userName"));
            r.setDate(rs.getString("pdate"));
            records.add(r);
        }
        rs.close();
        stmt.close();
        connect.close();
        return records;
    }

}
