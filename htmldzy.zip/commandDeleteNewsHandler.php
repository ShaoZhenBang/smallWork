<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
$selectedNews=$_POST["selectedNews"];
$sqlC->query("DELETE FROM news WHERE title='{selectedNews}'");
$sqlC->query("DELETE FROM comments WHERE title='{selectedNews}'");
