<!DOCTYPE html>
<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<link rel="stylesheet" href="basic.css">
<script>
    let xmlHttp;
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    function fucDelete(){
        let boxes=document.getElementsByName("comment");
        for(let i=0;i<boxes.length;i++){
            if(boxes[i].checked){
                let rs=boxes[i].value.split(";");
                let su=rs[0];
                let tt=rs[1];
                xmlHttp.open("post", "commandDeleteCommentsHandler.php");
                xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlHttp.send("selectedUser="+su+"&targetTitle="+tt);
            }
        }
        location.reload();
    }
</script>
<body background="image/background2.jpg">
<?php
$result=$sqlC->query("SELECT * FROM comments");
echo '<table align="center" border="2" width="400">';
echo '<caption><h3>评论信息</h3></caption>';
echo '<tr>';
echo '<th>选择删除</th><th>新闻标题</th><th>用户名</th><th>评论</th>';
echo '</tr>';
while($rs=mysqli_fetch_assoc($result)){
    echo '<tr align="center">';
    echo '<td>';
    echo '<input type="checkbox" name="comment" value="';
    echo $rs["userName"].";".$rs["newsTitle"];
    echo '">';
    echo '</td>';
    echo '<td>';
    echo $rs["newsTitle"];
    echo '</td>';
    echo '<td>';
    echo $rs["userName"];
    echo '</td>';
    echo '<td>';
    echo $rs["comment"];
    echo '</td>';
    echo '</tr>';
}
echo '</table>';
?>
<div align="center"><input type="button" value="DELETE" class="button" onclick="fucDelete()"/></div>
</body>
</html>