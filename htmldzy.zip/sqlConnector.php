<?php
class sqlConnector{
    private $connect;
    public function __construct(){
        $this->connect = new mysqli("localhost","root","","newsmanager");
    }
    public function query($sql){
        return $this->connect->query($sql);
    }
}

