<?php
include 'sqlConnector.php';
header('Content-type:text/html;charset=utf-8');
mysqli_query("set names 'utf-8'");
session_start();
$sqlC=new sqlConnector();
$result=$sqlC->query("SELECT*FROM news where id='{$_SESSION['news']}'");
$rs=mysqli_fetch_assoc($result);
$operation = $_POST["operation"];
$username = $_SESSION["userName"];
$comment = $_POST["comment"];
$targetTitle=$rs["title"];
if (!(mysqli_fetch_assoc($sqlC->query("SELECT*FROM comments WHERE userName='{$username}' AND newsTitle='{$targetTitle}'")))) {
    $operation = "insert";
}
switch ($operation) {
    case "insert":
        $sqlC->query("INSERT INTO comments(newsTitle,userName, comment) VALUES ('{$targetTitle}','{$username}','{$comment}')");
        break;
    case "delete":
        $sqlC->query("DELETE FROM comments WHERE userName='{$username}'AND newsTitle='{$targetTitle}'");
        break;
}
$new = $sqlC->query("SELECT comment from comments where username='{$username}' AND newsTitle='{$targetTitle}'");
$newComment = strval(mysqli_fetch_assoc($new));
echo time()."    ".$newComment;
