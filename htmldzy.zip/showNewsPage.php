<!DOCTYPE html>
<?php
session_start();
include 'sqlConnector.php';
header('Content-type:text/html;charset=utf-8');
$sqlC=new sqlConnector();
?>
<html lang="en">
<head>
<style type="text/css">
    div{
        width: 1002px;
        margin: 0 auto;
    }
    .a{
        margin-top: 150px;
        width: 1002px;
    }
    .a h1{
        float: left;
        font-size: 40px;
        color: #565656;
    }
    .b{

    }
    .a a{
        float: left;
        font-size: 30px;
        color: #565656;
        line-height: 50px;
    }
    </style>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="https://ajax.aspnetcdn.com/ajax/jquery/jquery-3.5.1.min.js"></script>
</head>
<script>
    let xmlHttp;
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    function ajaxRequest(str){
        var operation=str;
        if(operation=="delete"){
            var comment=document.getElementById("targetComment").innerHTML;
        }else{
            var comment=document.getElementById("addcomment").innerHTML;
        }
        xmlHttp.open("post", "comment.php");
        xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlHttp.send("operation="+operation+"&comment="+comment);
        xmlHttp.onreadystatechange=updateComment;
    }
    function updateComment(){
        if(xmlHttp.readyState===4){
            if(xmlHttp.status===200){
                document.getElementById().innerHTML=xmlHttp.responseText;
            }
        }
    }
</script>
<body background="image/background1.jpg">
<?php
    $rs=$sqlC->query("SELECT*FROM news where id='{$_SESSION['news']}'");
    $rows=mysqli_fetch_assoc($rs);
    $memo=str_replace("\n","</br>",$rows["newsInformation"]); 
            echo "<div class='all'>";
            echo "<div class='a'>";
            echo "<h1>";
            echo $rows["title"];
            echo "</h1>";
            echo "</br>";
            echo "</div>";
            echo "<div class='a'>";
            echo "<p>";
            echo $rows["author"];
            echo "</p>";
            echo "</div>";
            echo "<div class='a'>";
            echo "<p>";
            echo $memo;
            echo "</p>";
            echo "</div>";
            echo "</div>";

?>
<div>
<?php
    $result=$sqlC->query("SELECT *FROM comments WHERE newsTitle='{$rows['title']}'");
    echo '<table align="center" border="2" width="400">';
    echo '<caption><h3>评论信息</h3></caption>';
    echo '<tr>';
    echo '<th>用户名</th><th>评论</th><th></th>';
    echo '</tr>';
    while($rs2=mysqli_fetch_assoc($result)){
        echo '<tr align="center">';
        echo '<td>';
        echo $rs2["userName"];
        echo '</td>';
        if($rs2["userName"]===$_SESSION["userName"]) {
            echo '<td id="targetComment">';
            echo $rs2["comment"];
            echo '</td>';
            echo '<td>';
            echo '<button  type="button" id="delete" onclick="ajaxRequest(this.id)" >删除</button>';
            echo '</td>';
        }else{echo '<td>';  
            echo $rs2["comment"];
            echo '</td>'; 
            echo '<td>';
            echo '</td>';
        }
        echo '</tr>';
    }
    if($_SESSION["identity"] != "administrator"){
        echo '</table>';
    echo '<p>用户：';
    echo $_SESSION["userName"];
    echo '</p>';
    
    echo '<textarea id="addcomment" rows="10" cols="60"></textarea>';
    echo '<button type="button" id="insert" onclick="ajaxRequest(this.id)" >添加</button>';
    }
    
?>
</div>
</body>
</html>
