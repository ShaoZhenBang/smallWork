<?php
include 'sqlConnector.php';
header('Content-type:text/html;charset=utf-8');
$sqlC=new sqlConnector();
$userName=$_POST["username"];
$password=$_POST["password"];
$result=$sqlC->query("SELECT*FROM user where userName='{$userName}'");
if(mysqli_fetch_assoc($result)){
    echo "<script type='text/javascript'> if(confirm('该用户已存在,是否前往登录?')){location.href='Login.html'}else{location.href='register.html'}</script>";
}else{
    $sqlC->query("INSERT INTO users(userName,password) VALUES ('{$userName}','{$password}')");
    echo "<script type='text/javascript'>alert('注册成功!'); location.href='Login.html' </script>";
}


