<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
$selectedUser=$_POST["selectedUser"];
$sqlC->query("DELETE FROM users WHERE userName='{$selectedUser}'");
$sqlC->query("DELETE FROM comments WHERE userName='{$selectedUser}'");
