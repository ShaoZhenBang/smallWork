<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
$selectedUser=$_POST["selectedUser"];
$targetTitle=$_POST["targetTitle"];
$sqlC->query("DELETE FROM comments WHERE userName='{$selectedUser}' AND newsTitle='{$targetTitle}' ");
