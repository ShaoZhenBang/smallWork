<?php   session_start();
        if(!isset($_SESSION["case"])){
            $_SESSION["case"]=0;
        }
    ?>
    <html lang="en">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <title>分类页面</title>
    <style type="text/css">
    .page{            
        text-align: center;           
         margin-top: 50px;  
         width: 1002px;   
         padding-top:350px;   
        }

    .page a, .page span{            
        text-decoration: none;            
        border:1px solid #f9d52b;            
        padding: 5px 7px;            
        color: #767675;            
        cursor: pointer;        
    }
    .page a:hover,.page span:hover{            
        color: red;  }
    div{
        width: 800px;
        margin-left: 200px ;
        margin-right: 200px ;
    }
    .a{
        margin-top: 150px;
        width: 800px;
        margin-left: 200px ;
        margin-right: 1000px ;
    }
    .a h1{
        float: left;
        font-size: 100px;
        color: #565656;
        line-height: 200px;
    }
    .a a{
        float: left;
        font-size: 25px;
        color: #565656;
        line-height: 50px;
    }
    </style>
<script>
function ajaxRequest(str)
{
var xmlhttp;

if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.open("GET","change.php?id="+str,true);
xmlhttp.send();
}

</script>
</head>
<body background="image/background1.jpg">
    
    <div class="a">
    <?php
        echo "<h1>";
        echo $_SESSION["kind"];
        echo "</h1>";
    ?>
    </div>
    <div>
    <div class="a">
    <?php
    $i=$_SESSION["kind"];
    $conn=mysqli_connect("localhost","root","","newsmanager"); 
    if (mysqli_connect_errno($conn)) { 
        die("连接 MySQL 失败: " . mysqli_connect_error()); 
    }
    mysqli_query($conn,"set names utf8"); 
    $sql = "SELECT * FROM news ";
    $result = mysqli_query($conn, $sql);
    $a=array();
    while($row=mysqli_fetch_assoc($result)){
        if($i==$row["kind"]){
            array_push($a,$row["id"]);
        }
    }
    $result2 = mysqli_query($conn, $sql);
    while($row2=mysqli_fetch_assoc($result2)){
        for($x=0; $x<5; $x++){
            if($row2["id"]==$a[$x]){
               echo '<a href="showNewsPage.php" onclick="ajaxRequest(this.id)" id="'.$row2['id'].'">';
               echo $row2["title"];
               echo "</a>";
            }
        }
    }
    ?>
    </div>
    <div class="page">
        <a href="kind.php" onclick="(function(){<?php $_SESSION['case']= $_SESSION['case']-5; ?>})()">上一页</span>
        <a href="kind.php" onclick="(function(){<?php $_SESSION['case']=0; ?>})()">1</a>
        <a href="kind.php" onclick="(function(){<?php $_SESSION['case']=5; ?>})()">2</a>
        <a href="kind.php" onclick="(function(){<?php $_SESSION['case']=10; ?>})()">3</a>
        <a href="kind.php" onclick="(function(){<?php $_SESSION['case']= $_SESSION['case']+5; ?>})()">下一页</span>
</div>
</div>
</body>
</html>