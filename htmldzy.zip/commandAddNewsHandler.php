<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
$author=$_POST["author"];
$newsTitle=$_POST["newsTitle"];
$newsInformation=$_POST["newsInformation"];
$kind=$_POST["kind"];
$id=$_POST["id"];
$sqlC->query("INSERT INTO news(id,kind,author,title,newsInformation) VALUES ('{$id}','{$kind}','{$author}','{$newsTitle}','{$newsInformation}')");