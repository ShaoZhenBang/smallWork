<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="UTF-8">

</head>
<script>
    let xmlHttp;
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    function fucAdd(){
        xmlHttp.open("post", "commandAddNewsHandler.php");
        xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlHttp.send("id="+document.getElementById("id").value+"&kind="+document.getElementById("kind").value+"&author="+document.getElementById("author").value+"&newsTitle="+document.getElementById("title").value+"&newsInformation="+document.getElementById("information").value);
    }
</script>
<body background="image/background2.jpg">
<div style="text-align: center;"><h1>新闻添加</h1></div>
<form>
    <div>
        <label for="id">id</label>
        <input type="text" id="id" name="id" />
    </div>
    <div>
        <label for="kind">类别</label>
        <input type="text" id="kind" name="kind" />
    </div>
    
    <div>
        <label for="author">作者</label>
        <input type="text" id="author" name="author" />
    </div>
    <div>
        <label for="title">新闻标题</label>
        <input type="text" id="title" name="newsTitle" />
    </div>
    <div><label for="information">新闻内容</label></div>
    <textarea id="information" name="newsInformation" rows="30" cols="80"></textarea>
    <div>
        <input type="button" class="button" onclick="fucAdd()" value="Add">
    </div>
</form>
</body>
</html>