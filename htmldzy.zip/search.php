<?php
session_start();
$i=$_GET["search"];
$conn=mysqli_connect("localhost","root","","newsmanager"); 
if (mysqli_connect_errno($conn)) { 

    die("连接 MySQL 失败: " . mysqli_connect_error()); 

    }

mysqli_query($conn,"set names utf8"); 
$sql = "SELECT * FROM news ";

$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_assoc($result)){
    if($row["title"]==$i){
        $_SESSION["news"]=$row["id"];
        header("Location: showNewsPage.php");
    }
}
echo "<script>alert('未找到该新闻');location.href='originalPage.php';</script>";
?>