<!DOCTYPE html>
<?php
include 'sqlConnector.php';
$sqlC=new sqlConnector();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<link rel="stylesheet" href="basic.css">
<script>
    let xmlHttp;
    if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    function fucDelete(){
        let boxes=document.getElementsByName("user");
        for(let i=0;i<boxes.length;i++){
            if(boxes[i].checked){
                let un=boxes[i].value;
                xmlHttp.open("post", "commandDeleteUsersHandler.php");
                xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlHttp.send("selectedUser="+un);
            }
        }
        if(document.getElementById("toSelectUsers").value!==""){
            let selected=document.getElementById("toSelectUsers").value;
            let sl=selected.split(";");
            for(let i=0;i<sl.length;i++){
                xmlHttp.open("post", "commandDeleteUsersHandler.php");
                xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlHttp.send("selectedUser="+sl[i]);
            }
        }
        location.reload();
    }
</script>
<body background="image/background2.jpg">
<?php
$result=$sqlC->query("SELECT * FROM users");
echo '<table align="center" border="2" width="400">';
echo '<caption><h3>用户信息</h3></caption>';
echo '<tr>';
echo '<th>选择删除</th><th>用户名</th><th>密码</th>';
echo '</tr>';
while($rs=mysqli_fetch_assoc($result)){
    echo '<tr align="center">';
    echo '<td>';
    echo '<input type="checkbox" name="user" value="';
    echo $rs["userName"];
    echo '">';
    echo '</td>';
    echo '<td>';
    echo $rs["userName"];
    echo '</td>';
    echo '<td>';
    echo $rs["password"];
    echo '</td>';
    echo '</tr>';
}
echo '</table>';
?>
<div align="center"><input type="text" id="toSelectUsers"/></div>
<div align="center">输入用户名删除用户，各个用户名用";"隔开</div>
<div align="center"><input type="button" value="DELETE" class="button" onclick="fucDelete()"/></div>
</body>
</html>

