<?php
session_start();
$t=$_GET["id"];
$_SESSION["news"]=$t;
?>