
<html lang="en">

<head><?php   session_start();
    
?>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>新闻首页</title>

    <link rel="stylesheet" href="originalPage.css">
    <script>
function ajaxRequest(str)
{
var xmlhttp;

if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.open("GET","change.php?id="+str,true);
xmlhttp.send();
}
function ajaxRequest2(str)
{
var xmlhttp;

if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.open("GET","change2.php?kind="+encodeURIComponent(str),true);
xmlhttp.send();
}

</script>
<script type="text/javascript" src="jquery-1.12.3.min.js"></script>    
<script>
$(document).ready(function(){                          
    $(".clickButton span").click(function(){                   
        $(".imgs img").attr("src",$(this).attr('href'));
        $(".imgs img").attr("alt",$(this).attr('name'));
        return false;  
    });
    var imgs=['img/1.jpg','img/2.jpg','img/3.jpg','img/4.jpg','img/5.jpg'];
    var write=['潘建伟：量子计算正从“玩具”变成“工具”','随“嫦娥五号”奔月的种子发芽了','北京：科技助力核酸检测','四川都江堰龙池国家森林公园云雾缭绕 美如仙境','日本金枪鱼拍卖会拍出2080万日元天价鱼'];
	var i=0;
    setInterval("slideChange()",2000);
	slideChange=function(){
		i+=1;
        if(i==5) i=0; 
        var c=i+1;
        var b=c.toString(); 
        $(".imgs img").attr("src",imgs[i]);
        $(".imgs img").attr("alt",write[i]);
        $(".imgs img").attr("id",b);
        document.getElementById("ch").innerHTML=write[i];
	}
});
</script>

</head>
 
<body background="image/background1.jpg">
    

    <div class="header_con">

        <h1>
            <img src="image/logo.png" class="logo" alt="" >
        </h1>
        <div>
        <a href="Login.html"><img width="40px" height="50px" src="image/login.png"></a>
        <a href="register.html"><img width="40px" height="50px" src="image/rig.png"></a>
        </div>

        <form action="search.php" method="get">
            <input type="text" class="search" value="SEARCH..." name="search">
            
            <button type="submit" class="btn" value="Submit">搜索</button>
            
        </form>
    </div>

    <div id="nav">

        <div class="nav_con">
            <ul>
                <li class="margin-left"><a href="kind.php" id="时政" onclick="(function(){<?php $_SESSION['kind']='时政'; ?>})()">时政</a></li>
                <li><a href="kind.php" id="国际" onclick="ajaxRequest2(this.id)">国际</a></li>
                <li><a href="kind.php" id="社会" onclick="ajaxRequest2(this.id)">社会</a></li>
                <li><a href="kind.php" id="财经" onclick="ajaxRequest2(this.id)">财经</a></li>
                <li><a href="kind.php" id="娱乐" onclick="ajaxRequest2(this.id)">娱乐</a></li>
                <li><a href="kind.php" id="体育" onclick="ajaxRequest2(this.id)">体育</a></li>
                <li><a href="kind.php" id="军事" onclick="ajaxRequest2(this.id)">军事</a></li>
                <li><a href="kind.php" id="科技" onclick="ajaxRequest2(this.id)">科技</a></li>
            </ul>
        </div>
    </div>

    <div id="banner">
 
        <div class="banner_con">
        <div class="imgsBox">
	<div class="imgs">
		<a href="showNewsPage.php" ><img id="1"  src="img/1.jpg" onclick="ajaxRequest(this.id)" width="700px" height="350px" alt="潘建伟：量子计算正从“玩具”变成“工具”"/></a>
    </div>
    <div class="write">
		<p id="ch">潘建伟：量子计算正从“玩具”变成“工具”</p>
	</div>
	<div class="clickButton">
		<div >
			<span class="active" href="img/1.jpg" name="潘建伟：量子计算正从“玩具”变成“工具”"></span>
			<span class="" href="img/2.jpg" name="随“嫦娥五号”奔月的种子发芽了"></span>
			<span class="" href="img/3.jpg"name="北京：科技助力核酸检测"></span>
			<span class="" href="img/4.jpg" name="四川都江堰龙池国家森林公园云雾缭绕 美如仙境"></span>
			<span class="" href="img/5.jpg" name="日本金枪鱼拍卖会拍出2080万日元天价鱼"></span>
		</div>
	</div>
</div>

        </div>
    </div>

    <div class="news_con">

        <div class="news_l">
            <h3 class="news_title">最新消息</h3>
            <ul class="news_list">
                <li>
                    <a href="showNewsPage.php" id="6"   onclick="ajaxRequest(this.id)">山水情深——跟着总书记一起建设美丽中国</a>
                    <span>2021年01月06日</span>
                </li>
                <li>
                    <a href="showNewsPage.php" id="7"   onclick="ajaxRequest(this.id)">31省份增本土23例 石家庄全方位升级防疫措施</a>
                    <span>2021年01月06日</span>
                </li>
                <li>
                    <a href="showNewsPage.php" id="8"   onclick="ajaxRequest(this.id)">1月7日起，全国已购火车票退票不收取手续费</a>
                    <span>2021年01月06日</span>
                </li>
                <li>
                    <a href="showNewsPage.php" id="9"   onclick="ajaxRequest(this.id)">特朗普签令禁与支付宝等中国应用交易 中方回应</a>
                    <span>2021年01月06日</span>
                </li>
                <li>
                    <a href="showNewsPage.php" id="10"   onclick="ajaxRequest(this.id)">报告揭穿德国学者五大谎言</a>
                    <span>2021年01月06日</span>
                </li>
                <li>
                    <a href="showNewsPage.php" id="11"   onclick="ajaxRequest(this.id)">中消协秘书长朱剑桥谈直播带货乱象</a>
                    <span>2021年01月06日</span>
                </li>
            </ul>
 
        </div>

        <div class="news_c">
            <h3 class="news_title">时政</h3></br>
            <a class="txt1" href="showNewsPage.php" id="12"   onclick="ajaxRequest(this.id)">国办：进一步优化地方政务服务便民热线</a></br>
            <a class="txt2" href="showNewsPage.php" id="13"   onclick="ajaxRequest(this.id)">我们培养的学生，一定不能成为“精致的利己主义者”</a></br>
            <a class="txt1" href="showNewsPage.php" id="14"   onclick="ajaxRequest(this.id)">习近平如何用“关键变量”撬动中国未来？</a>
        </div>

        <div class="news_r">
            <h3 class="news_title">国际</h3></br>
            <a class="txt3" href="showNewsPage.php" id="15"   onclick="ajaxRequest(this.id)">朝鲜劳动党八大金正恩做报告：夯实国家防卫力量</a>
            <a  href="showNewsPage.php" id="15"   onclick="ajaxRequest(this.id)"><img src="img/6.jpg"  width="180px" height="120px" alt="" ></a>
 
        </div>
    </div>

    <div class="case_con">
        <h3>娱乐</h3>
        <div class="case_box">
            <dl>
            <a class="img1" href="showNewsPage.php" id="16"   onclick="ajaxRequest(this.id)"><img src="img/7.jpg" width="210px" height="136px"  alt="" ></a>
            <a class="txt3" href="showNewsPage.php" id="16"   onclick="ajaxRequest(this.id)">3天近13亿！2021元旦档电影票房为何能创新纪录？</a>
            </dl>
            <dl>
            <a class="img1" href="showNewsPage.php" id="17"   onclick="ajaxRequest(this.id)"><img src="img/8.jpg" width="210px" height="136px"  alt="" ></a>
            <a class="txt3" href="showNewsPage.php" id="17"   onclick="ajaxRequest(this.id)">双女主剧抢滩荧屏 “她俩的故事”不应只有“闺蜜情”样式</a>
            </dl>
            <dl>
            <a class="img1" href="showNewsPage.php" id="18"   onclick="ajaxRequest(this.id)"><img src="img/9.jpg" width="210px" height="136px"  alt="" ></a>
            <a class="txt3" href="showNewsPage.php" id="18"   onclick="ajaxRequest(this.id)">王凯谈《大江大河2》：宋运辉要适应当独立掌舵人</a>
            </dl>
            <dl>
            <a class="img1" href="showNewsPage.php" id="19"   onclick="ajaxRequest(this.id)"><img src="img/10.jpg" width="210px" height="136px"  alt="" ></a>
            <a class="txt3" href="showNewsPage.php" id="19"   onclick="ajaxRequest(this.id)">上综艺不务正业？郎朗回应：今年的综艺告一段落</a>
            </dl>
        </div>
    </div>

    <div id="links">

        <div class="links_con">

            <div class="links_l">
                <h3 class="links_title">财经</h3>
                <ul class="links_list">
                    <li>
                        <a href="showNewsPage.php" id="20"   onclick="ajaxRequest(this.id)">事关水电气暖，国家出手！这些不合理收费取消！</a>
                    </li>
                    <li>
                        <a href="showNewsPage.php" id="21"   onclick="ajaxRequest(this.id)">家用抗老美容仪，是“黑科技”还是“忽悠术”？</a>
                    </li>
                    <li>
                        <a href="showNewsPage.php" id="22"   onclick="ajaxRequest(this.id)">“羊贵妃”来了？！卖一只，挣300元！养殖户笑了</a>
                    </li>
                    <li>
                        <a href="showNewsPage.php" id="23"   onclick="ajaxRequest(this.id)">外汇局部署今年重点工作 防范跨境资本异常流动风险</a>
                    </li>
                    <li>
                        <a href="showNewsPage.php" id="24"   onclick="ajaxRequest(this.id)">31省份已发布塑料污染治理相关实施方案或行动计划</a>
                    </li>
                </ul>
            </div>

            <div class="links_c">
                <h3 class="links_title">体育</h3>
                <ul class="links_list">
                <a  href="showNewsPage.php" id="25"   onclick="ajaxRequest(this.id)">2023中国亚洲杯赛期确定 比赛周期31天历史最长</a>
                <a  href="showNewsPage.php" id="25"   onclick="ajaxRequest(this.id)"><img src="img/11.jpg"  width="250px" height="130px" alt="" ></a>
                </ul>
            </div>

            <div class="links_c">
                <h3 class="links_title">社会</h3>
                <ul class="links_list">
                <a  href="showNewsPage.php" id="26"   onclick="ajaxRequest(this.id)">多地汽车零部件外包装核酸阳性 专家：系员工带病作业引起</a>
                <a  href="showNewsPage.php" id="26"   onclick="ajaxRequest(this.id)"><img src="img/12.jpg"  width="250px" height="130px" alt="" ></a>
                </ul>
            </div>
    </div>
    </div>

    <div class="footer_con">

<?php
if(isset($_SESSION["identity"])){
        if($_SESSION["identity"]==="administrator"){
            echo "<a id='commandUsers'  href='ChooseBehaviour.html'>管理员界面</a>";
        }
    }?>
        

        <p class="footer_r" id="1" >
            潘晨阳&邵振邦
        </p>
    </div>
</body>
 
</html>