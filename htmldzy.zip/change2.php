<html lang="en">
<!-- 确定语言形态 -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<?php
session_start();
$t=$_GET["kind"];
$_SESSION["kind"]=$t;
?>
</head>
</html>