<?php
session_start();
session_unset();
session_destroy();
echo "<script>alert('注销成功!');location.href='originalPage.php';</script>";