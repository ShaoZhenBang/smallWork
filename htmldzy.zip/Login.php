<?php
include 'sqlConnector.php';
header('Content-type:text/html;charset=utf-8');
$sqlC=new sqlConnector();
$userName=$_POST["username"];
$password=$_POST["password"];
if(strstr($userName,'Administrator')){
    $aName=substr($userName,13);
    $ifRight=$sqlC->query("SELECT password from administrator where id='{$aName}' and password='{$password}'");
    if (mysqli_fetch_assoc($ifRight)) {
        session_start();
        $_SESSION["identity"] = "administrator";
        echo "<script>alert('登录成功!');location.href='originalPage.php';</script>";
    }
}else {
    $ifExist = $sqlC->query("SELECT username from users where userName='{$userName}'and password='{$password}'");
    if (mysqli_fetch_assoc($ifExist)) {
        session_start();
        $_SESSION["identity"] = "user";
        $_SESSION["userName"] = $userName;
        echo "<script>alert('登录成功!');location.href='originalPage.php';</script>";
    } else {
        echo "<script type='text/javascript'> if(confirm('用户未注册，是否前往注册?')){location.href='register.html'}else{location.href='original.html'}</script>";
    }
}